const troll = require("./icons/troll.png");
const swap = require("./icons/swap.png");
const trollresult = require("./icons/trollresult.png");
const moon = require("./icons/moon.png");
const sun = require("./icons/sun.png");
const deleted = require("./icons/delete.png");
const topArrow = require("./icons/topArrow.png");
const insta = require("./icons/insta.png");

export { troll, swap, trollresult, sun, moon, deleted, topArrow, insta };
